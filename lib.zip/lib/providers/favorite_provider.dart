import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/favorite_model.dart';

class FavoriteProvider extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  List<FavoriteModel> _favorites = [];
  bool _isLoading = false;
  String? _errorMessage;

  final Set<String> _togglingIds = {};
  String? _loadedUserId;

  List<FavoriteModel> get favorites => _favorites;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  int get favoriteCount => _favorites.length;

  Future<void> loadFavorites({required String userId}) async {
    if (_loadedUserId == userId && !_isLoading) return;

    _setLoading(true);
    _clearError();

    try {
      final snapshot = await _firestore
          .collection('favorites')
          .where('userId', isEqualTo: userId)
          .orderBy('createdAt', descending: true)
          .get();

      _favorites = snapshot.docs
          .map((doc) => FavoriteModel.fromJson(doc.id, doc.data()))
          .toList();

      _loadedUserId = userId;
      _setLoading(false);
    } catch (e) {
      _setError('Gagal memuat favorit: $e');
      _setLoading(false);
      rethrow;
    }
  }

  Future<void> addFavorite({
    required String userId,
    required String destinationId,
    required String destinationName,
    String? imageUrl,
    double? rating,
    String? kategori,
  }) async {
    _clearError();

    try {
      if (isFavorite(destinationId)) {
        throw Exception('Sudah ditambahkan ke favorit');
      }

      final existing = await _firestore
          .collection('favorites')
          .where('userId', isEqualTo: userId)
          .where('destinationId', isEqualTo: destinationId)
          .limit(1)
          .get();

      if (existing.docs.isNotEmpty) {
        final model = FavoriteModel.fromJson(
          existing.docs.first.id,
          existing.docs.first.data(),
        );
        if (!_favorites.any((f) => f.destinationId == destinationId)) {
          _favorites.insert(0, model);
          notifyListeners();
        }
        return;
      }

      final docRef = _firestore.collection('favorites').doc();
      final favorite = FavoriteModel(
        id: docRef.id,
        userId: userId,
        destinationId: destinationId,
        destinationName: destinationName,
        imageUrl: imageUrl,
        rating: rating,
        kategori: kategori,
        createdAt: DateTime.now(),
      );

      await docRef.set(favorite.toJson());
      _favorites.insert(0, favorite);
      notifyListeners();
    } catch (e) {
      _setError('Gagal menambah favorit: $e');
      rethrow;
    }
  }

  // ── REMOVE: cari dulu by destinationId, kalau tidak ada cari langsung di Firestore ──
  Future<void> removeFavorite({required String destinationId}) async {
    _clearError();

    try {
      // Cari di list lokal
      FavoriteModel? favorite;
      try {
        favorite = _favorites.firstWhere(
          (fav) => fav.destinationId == destinationId,
        );
      } catch (_) {
        favorite = null;
      }

      if (favorite != null) {
        // Hapus dari Firestore pakai doc ID
        await _firestore.collection('favorites').doc(favorite.id).delete();
      } else {
        // Fallback: cari langsung di Firestore by destinationId
        final snapshot = await _firestore
            .collection('favorites')
            .where('destinationId', isEqualTo: destinationId)
            .limit(1)
            .get();

        if (snapshot.docs.isNotEmpty) {
          await snapshot.docs.first.reference.delete();
        }
      }

      // Hapus dari list lokal & update UI
      _favorites.removeWhere((fav) => fav.destinationId == destinationId);
      notifyListeners();
    } catch (e) {
      _setError('Gagal menghapus favorit: $e');
      rethrow;
    }
  }

  Future<List<FavoriteModel>> getFavorites({required String userId}) async {
    try {
      final snapshot = await _firestore
          .collection('favorites')
          .where('userId', isEqualTo: userId)
          .orderBy('createdAt', descending: true)
          .get();

      return snapshot.docs
          .map((doc) => FavoriteModel.fromJson(doc.id, doc.data()))
          .toList();
    } catch (e) {
      _setError('Gagal mendapatkan favorit: $e');
      rethrow;
    }
  }

  bool isFavorite(String destinationId) {
    return _favorites.any((fav) => fav.destinationId == destinationId);
  }

  Future<void> toggleFavorite({
    required String userId,
    required String destinationId,
    required String destinationName,
    String? imageUrl,
    double? rating,
    String? kategori,
  }) async {
    if (_togglingIds.contains(destinationId)) return;

    _togglingIds.add(destinationId);
    try {
      if (isFavorite(destinationId)) {
        await removeFavorite(destinationId: destinationId);
      } else {
        await addFavorite(
          userId: userId,
          destinationId: destinationId,
          destinationName: destinationName,
          imageUrl: imageUrl,
          rating: rating,
          kategori: kategori,
        );
      }
    } finally {
      _togglingIds.remove(destinationId);
    }
  }

  FavoriteModel? getFavoriteByDestinationId(String destinationId) {
    try {
      return _favorites.firstWhere((fav) => fav.destinationId == destinationId);
    } catch (e) {
      return null;
    }
  }

  Future<void> clearAllFavorites({required String userId}) async {
    _clearError();

    try {
      final batch = _firestore.batch();
      for (var favorite in _favorites) {
        batch.delete(_firestore.collection('favorites').doc(favorite.id));
      }
      await batch.commit();
      _favorites.clear();
      notifyListeners();
    } catch (e) {
      _setError('Gagal menghapus semua favorit: $e');
      rethrow;
    }
  }

  List<FavoriteModel> getFavoritesByCategory(String category) {
    return _favorites.where((fav) => fav.kategori == category).toList();
  }

  List<FavoriteModel> getFavoritesSortedByRating() {
    final sorted = List<FavoriteModel>.from(_favorites);
    sorted.sort((a, b) => (b.rating ?? 0).compareTo((a.rating ?? 0)));
    return sorted;
  }

  List<FavoriteModel> searchFavorites(String query) {
    return _favorites
        .where(
          (fav) =>
              fav.destinationName.toLowerCase().contains(query.toLowerCase()),
        )
        .toList();
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void _setError(String message) {
    _errorMessage = message;
    notifyListeners();
  }

  void _clearError() {
    _errorMessage = null;
  }
}
